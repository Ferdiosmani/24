# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: 
# Based on code from youtube addon
#
# modified by: 24vakti.mk
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.24vakti'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "PLafTEQnjQ2cfiYw_UTzPY8zzPqrbSo74z" 	#ROMANI PROBLEMATIKA
YOUTUBE_CHANNEL_ID_2 = "PLafTEQnjQ2cfahlWG7_Bk7vEUrYLBt1C_"		#ROMANO POLITIKANO MAGAZINI *EUROROM*
YOUTUBE_CHANNEL_ID_3 = "PLafTEQnjQ2cfWO5cuthh0alctPLkpRX0I" 	#24VAKTI SHOW-2017
YOUTUBE_CHANNEL_ID_4 = "PLafTEQnjQ2ccEPHi0SveB0Xe7m68NCfxV" 	#DOKUMENTARNO PROGRAMA
YOUTUBE_CHANNEL_ID_5 = "PLafTEQnjQ2ce0bhLNwQT9TOshrafAs9fp" 	#BEJTULA RAMADAN MIX
YOUTUBE_CHANNEL_ID_6 = "PLafTEQnjQ2ccsMin3T0enByi0BhEoetcj" 	#RADICIONALNO ROMANI BALI/2017


# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="ROMANI PROBLEMATIKA",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Coat_of_arms_of_%C5%A0uto_Orizari_Municipality.svg/1200px-Coat_of_arms_of_%C5%A0uto_Orizari_Municipality.svg.png",
		fanart="http://balkon3.com/en/wp-content/uploads/2014/08/sutka.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ROMANO POLITIKANO MAGAZINI *EUROROM*",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.ytimg.com/vi/h5dodQpUYeE/maxresdefault.jpg",
		fanart="https://i.ytimg.com/vi/nuBErnrHWXE/maxresdefault.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="24VAKTI SHOW-2017",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://i.ytimg.com/vi/Q5xRIy72CdM/maxresdefault.jpg",
		fanart="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSGDdPMSd04Wp4I-YcFaqdZJJNfTNwbo6JpXsq9Fz4vctAmBDZ4",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="DOKUMENTARNO PROGRAMA",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://lh3.googleusercontent.com/JqYMTEmrUd4ZSKSgQQDFa8AVlzxSqSCa9M4jSoAHV8k2FfMkxUKh_k4jV2pRtCJyiZkRG6riKIM4-Hu0Pf63cHGjl3byIOFG1xZbYbmMBLTd7WyuOE3IvnknBHhaWgacyoNmFFenNFKwDpWZpPf2Uab7zqooqdrxSDYnAGt80tAbN08kduVQClROEL2fAtzhNsBg5BYxuNDXEGBLPEVq8-vtgR6IxiVXL53NoJi--70ZySo_gd1AUUowiKMjweMTA3ofI83vZqtN39Yh_3YXiioPrWDOwN-bKJXpH77xVw2hm7TI1qktEqhJDzWIiUt7BQqyjpc09KV6_rDmYy1DaJfTZfcWvUFXX5zO2vfU_uW0sm47wskuEhKLxh8TBw_64b96grelw3jKmGt9c5YLprNI3Am5YyLm9FjMnwTSpFwr46a3Bems5KP697zQ39NzaT-qAaaF9mBI9hrhkpKEBYXNsXH--OKiB3DajsWbo2KElFU2QM0fhoV4c1qlFgTy7JKS1kVSFTqypkA7ohrIOEgnUQR5FDqedJKmsu_pYWwQZnaTe2_dbiPqUGQt7eYWepcBHsstC4U4cjRFHkkdKTm1Tps4G_kZCxCZ9W9T7y-dqb65G-cB=s150-no",
		fanart="https://lh3.googleusercontent.com/JT7MTJuBUPLo25g8rG1fYR-e2-32UUvO3wstzldBn_xmbd68sg1aR42rrV2j0gbXVkpcdOipxRqr77yj0uqq46zE9lvd60byx8M1jndc3xCdx2t2LfXAnDoFkxNHCKo5HUULV65wObhBo0WEKojIxhMWsuRy91vVuvTKbRkIFr6Tqd-s_OP5vZNon00bcQ6zdl-EgBdmLqmYeGg7AGA7W0mkzUSVxSrdmKTwIvOdUOQ3oKX4Ijf6UASi60CVzD1QmvJlUrqNLQXy_KOZ-TYxkpnulYqHTOg7NXCN1ryPn2srzoaeaA2N22UrJMxfhmkO-fP75cEVz2VQ8wN_ngS2BMqI4P5hE9PUgdu6e2JsDXmtFlYxETIo-7pkQTckbNZOShsSO_YbQ0z20FaX07SDdi0r9LSTX-ed2yxwVf2zCC_d784yiCNQv9ehZ8mrIFa5K7Si6loQ3LX-zKV5WF7-g-Lmjr8qRfox0c051KJlAR692Xqicz05hNF94yR6FFwIqeC5mIaHPeK7ijhWGd40Ps1AxyK1eAQQFjZcmPJZRE9s4v3kXBYGPsQ5CHxZJFUH28H4WAqVY1DWlbZeNFpPGO5XWkWQOMhD5bkkh3TJm7p9MsJu=w427-h240-no",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="BEJTULA RAMADAN MIX",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://i.ytimg.com/vi/V857jnWxMf0/maxresdefault.jpg",
		fanart="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQn3vLHh4hgDvog4JMvMvAqfHTLFNYER3aZcRJJl7TPmckPoNWX",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="RADICIONALNO ROMANI BALI/2017",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSNYo2XhwQwZ4vNm_r4o4k2mBr6nGFi-jFnm6y6OPaOKzgiY1xj",
		fanart="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWxZZ6Vfro0NMnnHxbb2zc9YIuCDexmTd8HiRv0sR6bsJV4bdV",
        folder=True )
		


		
run()
